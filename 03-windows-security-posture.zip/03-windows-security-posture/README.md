# Windows Security Posture

A read-only PowerShell script that collects a structured snapshot of selected Windows 11 security settings and emits JSON to standard output.

The script is designed for inspection, not remediation. It does not change settings, start a malware scan, contact Windows Update, install software, write a report file, clear logs, or elevate itself.

## What it inspects

Where the relevant Windows components and permissions are available, the snapshot covers:

- Windows version and build information;
- active antivirus products and selected Microsoft Defender settings;
- network and firewall posture, including high-interest inbound rules;
- BitLocker, Secure Boot, TPM, and virtualization-based security status;
- User Account Control and remote-access configuration;
- SMB configuration, active shares, and share-access principals;
- local accounts and privileged local-group membership;
- automatic-logon indicators;
- Windows Update policy, service state, recent update events, and reboot indicators;
- listening TCP ports and owning process/service names;
- indicators of common remote-control or network-overlay software;
- Windows Hello policy, biometric devices, and related services; and
- a bounded sample of selected recent Security log events.

Each section handles access failures independently. A normal-user run can therefore return useful results while marking restricted sections `UnavailableOrDenied`.

## Privacy warning

The script deliberately omits several especially dangerous values: Defender exclusion contents, BitLocker recovery material and protector IDs, process paths and command lines, scheduled-task arguments, share filesystem paths, network names, exact local bind addresses, autologon credential values, and full event messages.

Even with those omissions, the JSON may still reveal sensitive information, including:

- local usernames and privileged-group members;
- share names and access principals;
- remote-logon usernames, source addresses, and authentication metadata;
- security-change actors and affected objects;
- installed security or remote-access product names;
- open ports, process IDs, process names, and service names;
- operating-system patch and security-feature posture; and
- machine-specific timing and configuration details.

Treat every real result as confidential. Do not commit it, attach it to a public issue, paste it into a chat, or upload it to an unapproved service. This repository contains no actual audit output.

## Requirements

- Windows 11
- Windows PowerShell 5.1 or PowerShell 7+
- The built-in Windows modules present on the machine

Some sections commonly require administrator rights. The script does not require external modules and does not install any.

## Safe usage

First review the script, open a normal (not elevated) PowerShell window, switch to the repository folder, and run:

```powershell
powershell.exe -NoProfile -File .\windows-security-audit-readonly.ps1
```

PowerShell 7 users can run:

```powershell
pwsh -NoProfile -File .\windows-security-audit-readonly.ps1
```

The output is JSON in the console. A normal-user run is the recommended first pass. If the report marks important sections unavailable and you knowingly want to inspect them, open an elevated PowerShell window and run the same unchanged command.

### Bound the Security event sample

The defaults inspect the previous 7 days and read at most 500 selected events. Accepted ranges are 1–30 days and 50–2,000 events:

```powershell
.\windows-security-audit-readonly.ps1 -RecentEventDays 3 -MaximumSecurityEvents 250
```

### Save output deliberately

The script itself does not create a report file. If you intentionally save one, choose a private location outside the cloned repository and restrict its access:

```powershell
.\windows-security-audit-readonly.ps1 |
    Set-Content -LiteralPath 'C:\PRIVATE_LOCATION\windows-security-posture.json' -Encoding utf8
```

Replace the placeholder with a private path that already exists. Remember that copies may persist in backups, sync services, terminal logs, and endpoint-management systems.

## Interpreting results

This is a posture snapshot, not a compliance verdict or proof of compromise. For example:

- A remote-control product indicator can be legitimate software.
- An unavailable section is not the same as a failed security control.
- A registry policy value may require Windows documentation and organizational context to interpret.
- A bounded event sample is not complete event history.
- The presence of a setting does not prove that every related runtime control is effective.

Use findings as prompts for careful follow-up with trusted Windows documentation or a qualified security professional. Do not apply bulk changes based solely on this output.

## Static verification

The repository includes a dependency-free parser and command-safety check. It does not run the audit:

```powershell
powershell.exe -NoProfile -File .\tests\Test-Static.ps1
```

Continuous integration runs the same check on Windows. It verifies PowerShell syntax, rejects fixed user-profile paths, and blocks a conservative list of mutating or network commands from entering the script unnoticed. This is a guardrail, not a formal proof that code is side-effect-free.

## License status

The included `LICENSE` reserves all rights while the owner chooses a long-term license. Public visibility alone does not grant permission to copy, modify, or redistribute the code.

## Contributing safely

Never include real audit output, screenshots, account names, network details, registry exports, event logs, or machine identifiers in a commit or issue. See `SECURITY.md` for private vulnerability-reporting guidance.
