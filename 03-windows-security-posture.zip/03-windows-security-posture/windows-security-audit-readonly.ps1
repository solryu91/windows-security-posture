<#
.SYNOPSIS
    Read-only Windows 11 security posture snapshot.

.DESCRIPTION
    This script performs only local PowerShell, CIM, and registry reads. It does
    not start a malware scan, contact Windows Update, change policy, enable
    logging, install software, write a report file, or modify the event logs.

    To reduce accidental disclosure, it deliberately omits:
      * Defender exclusion values and protected-folder paths (counts only)
      * BitLocker recovery passwords and key-protector IDs (types only)
      * process paths and command lines
      * scheduled-task arguments and definitions
      * share filesystem paths
      * Wi-Fi/network names and exact local bind addresses
      * registry autologon password values (presence only)
      * full event-log messages

    Run once in a normal PowerShell window. Sections marked in
    ElevationUsuallyNeeded may report UnavailableOrDenied. If the owner chooses,
    the same unchanged script can then be run from an elevated PowerShell window.
    It never attempts to elevate itself.
#>

[CmdletBinding()]
param(
    [ValidateRange(1, 30)]
    [int] $RecentEventDays = 7,

    [ValidateRange(50, 2000)]
    [int] $MaximumSecurityEvents = 500
)

function Invoke-AuditSection {
    param([Parameter(Mandatory)][scriptblock] $ScriptBlock)

    try {
        & $ScriptBlock
    }
    catch {
        [pscustomobject]@{
            Status        = 'UnavailableOrDenied'
            ErrorId       = [string] $_.FullyQualifiedErrorId
            ExceptionType = $_.Exception.GetType().FullName
        }
    }
}

function Read-RegistryValue {
    param(
        [Parameter(Mandatory)][string] $Path,
        [Parameter(Mandatory)][string] $Name
    )

    try {
        $key = Get-Item -LiteralPath $Path -ErrorAction Stop
        if (@($key.GetValueNames()) -contains $Name) {
            return $key.GetValue(
                $Name,
                $null,
                [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames
            )
        }
    }
    catch {
        return $null
    }
    return $null
}

function Test-RegistryValuePresent {
    param(
        [Parameter(Mandatory)][string] $Path,
        [Parameter(Mandatory)][string] $Name
    )

    try {
        $key = Get-Item -LiteralPath $Path -ErrorAction Stop
        return (@($key.GetValueNames()) -contains $Name)
    }
    catch {
        return $false
    }
}

function Read-RegistrySnapshot {
    param(
        [Parameter(Mandatory)][string] $Path,
        [Parameter(Mandatory)][string[]] $Names
    )

    $result = [ordered]@{}
    foreach ($name in $Names) {
        $result[$name] = Read-RegistryValue -Path $Path -Name $name
    }
    [pscustomobject] $result
}

function Read-ObjectProperty {
    param(
        [AllowNull()] $InputObject,
        [Parameter(Mandatory)][string] $Name
    )

    if ($null -eq $InputObject) {
        return $null
    }
    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -ne $property) {
        return $property.Value
    }
    return $null
}

function Get-SafeExecutableLeaf {
    param([AllowNull()][string] $Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $null
    }

    $candidate = $Value.Trim()
    if ($candidate.StartsWith('"')) {
        $closingQuote = $candidate.IndexOf('"', 1)
        if ($closingQuote -gt 1) {
            $candidate = $candidate.Substring(1, $closingQuote - 1)
        }
    }
    else {
        $candidate = ($candidate -split '\s+', 2)[0]
    }

    try {
        return [System.IO.Path]::GetFileName($candidate)
    }
    catch {
        return '<unparsed>'
    }
}

function Get-EventDataMap {
    param([Parameter(Mandatory)] $EventRecord)

    $map = @{}
    try {
        [xml] $xml = $EventRecord.ToXml()
        foreach ($data in @($xml.Event.EventData.Data)) {
            $name = [string] $data.Name
            if (-not [string]::IsNullOrWhiteSpace($name)) {
                $map[$name] = [string] $data.'#text'
            }
        }
    }
    catch {
        # Leave the map empty; the event ID and time remain useful.
    }
    return $map
}

function Get-FirstMapValue {
    param(
        [Parameter(Mandatory)][hashtable] $Map,
        [Parameter(Mandatory)][string[]] $Names
    )

    foreach ($name in $Names) {
        if ($Map.ContainsKey($name) -and -not [string]::IsNullOrWhiteSpace([string] $Map[$name])) {
            return [string] $Map[$name]
        }
    }
    return $null
}

$principal = [Security.Principal.WindowsPrincipal]::new(
    [Security.Principal.WindowsIdentity]::GetCurrent()
)
$isAdministrator = $principal.IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)
$eventWindowStart = (Get-Date).AddDays(-$RecentEventDays)

$report = [ordered]@{
    AuditMetadata = [pscustomobject]@{
        CollectedAt              = (Get-Date).ToString('o')
        RecentEventWindowStart   = $eventWindowStart.ToString('o')
        RunningAsAdministrator   = $isAdministrator
        ReadOnly                 = $true
        StartedMalwareScan       = $false
        ContactedWindowsUpdate   = $false
        WroteReportFile          = $false
        SensitiveValuesOmitted   = $true
        ElevationUsuallyNeeded   = @(
            'BitLocker volume details'
            'Secure Boot confirmation'
            'TPM details on some systems'
            'SMB server configuration and share permissions on some systems'
            'Windows optional-feature state'
            'Security event log'
        )
    }
}

$report.OS = Invoke-AuditSection {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    $cv = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop

    [pscustomobject]@{
        Caption          = $os.Caption
        Version          = $os.Version
        BuildNumber      = $os.BuildNumber
        UBR              = Read-ObjectProperty -InputObject $cv -Name 'UBR'
        DisplayVersion   = Read-ObjectProperty -InputObject $cv -Name 'DisplayVersion'
        EditionID        = Read-ObjectProperty -InputObject $cv -Name 'EditionID'
        InstallationType = Read-ObjectProperty -InputObject $cv -Name 'InstallationType'
        Architecture     = $os.OSArchitecture
        InstallDate      = $os.InstallDate
        LastBootUpTime   = $os.LastBootUpTime
    }
}

$report.ActiveAntivirusProducts = Invoke-AuditSection {
    @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{
                DisplayName  = $_.displayName
                ProductState = ('0x{0:X6}' -f [int] $_.productState)
                Timestamp    = $_.timestamp
            }
        })
}

$report.MicrosoftDefender = Invoke-AuditSection {
    if (-not (Get-Command -Name Get-MpComputerStatus -ErrorAction SilentlyContinue)) {
        throw 'Microsoft Defender status cmdlets are unavailable.'
    }

    $status = Get-MpComputerStatus -ErrorAction Stop
    $preference = Get-MpPreference -ErrorAction Stop
    $asrActions = @(Read-ObjectProperty -InputObject $preference -Name 'AttackSurfaceReductionRules_Actions')

    [pscustomobject]@{
        Status = [pscustomobject]@{
            AMServiceEnabled                = Read-ObjectProperty $status 'AMServiceEnabled'
            AntivirusEnabled                = Read-ObjectProperty $status 'AntivirusEnabled'
            AntispywareEnabled              = Read-ObjectProperty $status 'AntispywareEnabled'
            BehaviorMonitorEnabled          = Read-ObjectProperty $status 'BehaviorMonitorEnabled'
            IoavProtectionEnabled           = Read-ObjectProperty $status 'IoavProtectionEnabled'
            NISEnabled                      = Read-ObjectProperty $status 'NISEnabled'
            OnAccessProtectionEnabled       = Read-ObjectProperty $status 'OnAccessProtectionEnabled'
            RealTimeProtectionEnabled       = Read-ObjectProperty $status 'RealTimeProtectionEnabled'
            IsTamperProtected               = Read-ObjectProperty $status 'IsTamperProtected'
            DefenderSignaturesOutOfDate     = Read-ObjectProperty $status 'DefenderSignaturesOutOfDate'
            AntivirusSignatureLastUpdated   = Read-ObjectProperty $status 'AntivirusSignatureLastUpdated'
            AntivirusSignatureAge           = Read-ObjectProperty $status 'AntivirusSignatureAge'
            QuickScanAge                    = Read-ObjectProperty $status 'QuickScanAge'
            FullScanAge                     = Read-ObjectProperty $status 'FullScanAge'
            RebootRequired                  = Read-ObjectProperty $status 'RebootRequired'
        }
        Preferences = [pscustomobject]@{
            DisableRealtimeMonitoring       = Read-ObjectProperty $preference 'DisableRealtimeMonitoring'
            DisableBehaviorMonitoring       = Read-ObjectProperty $preference 'DisableBehaviorMonitoring'
            DisableIOAVProtection           = Read-ObjectProperty $preference 'DisableIOAVProtection'
            DisableScriptScanning           = Read-ObjectProperty $preference 'DisableScriptScanning'
            DisableArchiveScanning          = Read-ObjectProperty $preference 'DisableArchiveScanning'
            DisableRemovableDriveScanning   = Read-ObjectProperty $preference 'DisableRemovableDriveScanning'
            DisableBlockAtFirstSeen         = Read-ObjectProperty $preference 'DisableBlockAtFirstSeen'
            DisableIntrusionPreventionSystem = Read-ObjectProperty $preference 'DisableIntrusionPreventionSystem'
            MAPSReporting                   = Read-ObjectProperty $preference 'MAPSReporting'
            SubmitSamplesConsent            = Read-ObjectProperty $preference 'SubmitSamplesConsent'
            PUAProtection                   = Read-ObjectProperty $preference 'PUAProtection'
            EnableControlledFolderAccess    = Read-ObjectProperty $preference 'EnableControlledFolderAccess'
            EnableNetworkProtection         = Read-ObjectProperty $preference 'EnableNetworkProtection'
            CloudBlockLevel                 = Read-ObjectProperty $preference 'CloudBlockLevel'
            SignatureUpdateInterval         = Read-ObjectProperty $preference 'SignatureUpdateInterval'
            CheckForSignaturesBeforeScan    = Read-ObjectProperty $preference 'CheckForSignaturesBeforeRunningScan'
            ASRRuleCount                    = @(Read-ObjectProperty $preference 'AttackSurfaceReductionRules_Ids').Count
            ASRActionCounts                 = @($asrActions | Group-Object | ForEach-Object {
                [pscustomobject]@{ Action = [string] $_.Name; Count = $_.Count }
            })
        }
        ExclusionCountsOnly = [pscustomobject]@{
            Paths             = @(Read-ObjectProperty $preference 'ExclusionPath').Count
            Processes         = @(Read-ObjectProperty $preference 'ExclusionProcess').Count
            Extensions        = @(Read-ObjectProperty $preference 'ExclusionExtension').Count
            IPAddresses       = @(Read-ObjectProperty $preference 'ExclusionIpAddress').Count
            ASROnlyExclusions = @(Read-ObjectProperty $preference 'AttackSurfaceReductionOnlyExclusions').Count
            CFAAllowedApps    = @(Read-ObjectProperty $preference 'ControlledFolderAccessAllowedApplications').Count
            ProtectedFolders  = @(Read-ObjectProperty $preference 'ControlledFolderAccessProtectedFolders').Count
        }
    }
}

$report.NetworkProfiles = Invoke-AuditSection {
    @(Get-NetConnectionProfile -ErrorAction Stop | ForEach-Object {
        [pscustomobject]@{
            InterfaceIndex   = $_.InterfaceIndex
            NetworkCategory  = $_.NetworkCategory
            IPv4Connectivity = $_.IPv4Connectivity
            IPv6Connectivity = $_.IPv6Connectivity
        }
    })
}

$report.FirewallProfiles = Invoke-AuditSection {
    @(Get-NetFirewallProfile -PolicyStore ActiveStore -ErrorAction Stop | ForEach-Object {
        [pscustomobject]@{
            Name                    = $_.Name
            Enabled                 = $_.Enabled
            DefaultInboundAction    = $_.DefaultInboundAction
            DefaultOutboundAction   = $_.DefaultOutboundAction
            AllowInboundRules       = $_.AllowInboundRules
            AllowLocalFirewallRules = $_.AllowLocalFirewallRules
            NotifyOnListen          = $_.NotifyOnListen
            LogAllowed              = $_.LogAllowed
            LogBlocked              = $_.LogBlocked
        }
    })
}

$report.InboundRemoteAccessFirewallRules = Invoke-AuditSection {
    $remoteNamePattern = '(?i)remote\s*(desktop|assistance|management|service|utilities)|winrm|windows\s+remote\s+management|file\s+and\s+printer\s+sharing|network\s+discovery|openssh|ssh|smb|vnc|anydesk|teamviewer|rustdesk|screenconnect|connectwise|splashtop|remotepc|logmein|gotoassist|zoho\s+assist|dwagent|supremo|meshagent|simplehelp|bomgar|beyondtrust|dameware|radmin|atera|parsec|nomachine'
    $highInterestPorts = @('22','23','135','137','138','139','445','3389','5900','5901','5985','5986','8172','47001')
    $candidates = @()

    $enabledInboundAllows = @(Get-NetFirewallRule -PolicyStore ActiveStore -Direction Inbound -Enabled True -Action Allow -ErrorAction Stop)

    foreach ($rule in $enabledInboundAllows) {
        try { $ports = @($rule | Get-NetFirewallPortFilter -ErrorAction Stop) }
        catch { $ports = @() }
        try { $addresses = @($rule | Get-NetFirewallAddressFilter -ErrorAction Stop) }
        catch { $addresses = @() }
        try { $applications = @($rule | Get-NetFirewallApplicationFilter -ErrorAction Stop) }
        catch { $applications = @() }

        $localPortText = [string] ((@($ports | ForEach-Object { $_.LocalPort }) | Select-Object -Unique) -join ',')
        $protocolText = [string] ((@($ports | ForEach-Object { $_.Protocol }) | Select-Object -Unique) -join ',')
        $remoteAddresses = @($addresses | ForEach-Object { @($_.RemoteAddress) })
        $remoteScope = if (@($remoteAddresses | Where-Object { $_ -in @('Any','*','Internet') }).Count -gt 0) {
            'AnyOrInternet'
        }
        elseif (@($remoteAddresses | Where-Object { $_ -eq 'LocalSubnet' }).Count -gt 0) {
            'LocalSubnet'
        }
        elseif ($remoteAddresses.Count -gt 0) {
            'Restricted'
        }
        else {
            'Unknown'
        }

        $programText = [string] ((@($applications | ForEach-Object { $_.Program })) -join ' ')
        $descriptiveText = [string] ($rule.DisplayName, $rule.DisplayGroup, $rule.Name, $programText -join ' ')
        $nameOrProgramMatch = $descriptiveText -match $remoteNamePattern
        $portMatch = @($highInterestPorts | Where-Object {
            $localPortText -match ('(^|,)' + [regex]::Escape($_) + '(,|$)')
        }).Count -gt 0
        $publicOrAnyProfile = ([string] $rule.Profile) -match '(?i)Public|Any'
        $broadPublicAllow = ($remoteScope -eq 'AnyOrInternet') -and $publicOrAnyProfile

        if ($nameOrProgramMatch -or $portMatch -or $broadPublicAllow) {
            $candidates += [pscustomobject]@{
                DisplayName           = $rule.DisplayName
                DisplayGroup          = $rule.DisplayGroup
                Profile               = [string] $rule.Profile
                Protocol              = $protocolText
                LocalPorts            = $localPortText
                RemoteScope           = $remoteScope
                ApplicationFile       = @($applications | ForEach-Object {
                    Get-SafeExecutableLeaf -Value ([string] $_.Program)
                } | Where-Object { $_ } | Select-Object -Unique)
                PolicyStoreSourceType = [string] $rule.PolicyStoreSourceType
                WhyIncluded           = @(
                    if ($nameOrProgramMatch) { 'Remote-access name or application' }
                    if ($portMatch) { 'High-interest listening port' }
                    if ($broadPublicAllow) { 'Broad allow on Public/Any profile' }
                )
            }
        }
    }

    [pscustomobject]@{
        CandidateCount = $candidates.Count
        ShownCount     = [Math]::Min(250, $candidates.Count)
        Rules          = @($candidates | Sort-Object DisplayGroup, DisplayName | Select-Object -First 250)
    }
}

$report.BitLocker = Invoke-AuditSection {
    if (-not (Get-Command -Name Get-BitLockerVolume -ErrorAction SilentlyContinue)) {
        throw 'BitLocker cmdlets are unavailable.'
    }

    @(Get-BitLockerVolume -ErrorAction Stop | ForEach-Object {
        [pscustomobject]@{
            MountPoint          = $_.MountPoint
            VolumeType          = [string] $_.VolumeType
            VolumeStatus        = [string] $_.VolumeStatus
            ProtectionStatus    = [string] $_.ProtectionStatus
            LockStatus          = [string] $_.LockStatus
            EncryptionPercentage = $_.EncryptionPercentage
            EncryptionMethod    = [string] $_.EncryptionMethod
            AutoUnlockEnabled   = $_.AutoUnlockEnabled
            KeyProtectorTypes   = @($_.KeyProtector | ForEach-Object {
                [string] $_.KeyProtectorType
            } | Select-Object -Unique)
        }
    })
}

$report.SecureBoot = Invoke-AuditSection {
    if (-not (Get-Command -Name Confirm-SecureBootUEFI -ErrorAction SilentlyContinue)) {
        throw 'Secure Boot cmdlet is unavailable.'
    }
    [pscustomobject]@{
        SecureBootEnabled = [bool] (Confirm-SecureBootUEFI -ErrorAction Stop)
    }
}

$report.TPM = Invoke-AuditSection {
    if (-not (Get-Command -Name Get-Tpm -ErrorAction SilentlyContinue)) {
        throw 'TPM cmdlet is unavailable.'
    }
    $tpm = Get-Tpm -ErrorAction Stop
    [pscustomobject]@{
        TpmPresent                = Read-ObjectProperty $tpm 'TpmPresent'
        TpmReady                  = Read-ObjectProperty $tpm 'TpmReady'
        TpmEnabled                = Read-ObjectProperty $tpm 'TpmEnabled'
        TpmActivated              = Read-ObjectProperty $tpm 'TpmActivated'
        TpmOwned                  = Read-ObjectProperty $tpm 'TpmOwned'
        RestartPending            = Read-ObjectProperty $tpm 'RestartPending'
        AutoProvisioning          = Read-ObjectProperty $tpm 'AutoProvisioning'
        LockedOut                 = Read-ObjectProperty $tpm 'LockedOut'
        LockoutHealTime           = Read-ObjectProperty $tpm 'LockoutHealTime'
        ManufacturerVersion       = Read-ObjectProperty $tpm 'ManufacturerVersion'
        ManufacturerVersionFull20 = Read-ObjectProperty $tpm 'ManufacturerVersionFull20'
    }
}

$report.VirtualizationBasedSecurity = Invoke-AuditSection {
    $deviceGuard = Get-CimInstance -Namespace 'root/Microsoft/Windows/DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction Stop
    [pscustomobject]@{
        VirtualizationBasedSecurityStatus = $deviceGuard.VirtualizationBasedSecurityStatus
        SecurityServicesConfigured        = @($deviceGuard.SecurityServicesConfigured)
        SecurityServicesRunning           = @($deviceGuard.SecurityServicesRunning)
        AvailableSecurityProperties       = @($deviceGuard.AvailableSecurityProperties)
        RequiredSecurityProperties        = @($deviceGuard.RequiredSecurityProperties)
        CodeIntegrityPolicyEnforcement     = $deviceGuard.CodeIntegrityPolicyEnforcementStatus
        UserModeCodeIntegrityPolicy        = $deviceGuard.UsermodeCodeIntegrityPolicyEnforcementStatus
    }
}

$report.UAC = Invoke-AuditSection {
    Read-RegistrySnapshot -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Names @(
            'EnableLUA',
            'ConsentPromptBehaviorAdmin',
            'ConsentPromptBehaviorUser',
            'PromptOnSecureDesktop',
            'FilterAdministratorToken',
            'LocalAccountTokenFilterPolicy',
            'EnableInstallerDetection',
            'ValidateAdminCodeSignatures'
        )
}

$report.RemoteAccessConfiguration = Invoke-AuditSection {
    [pscustomobject]@{
        RemoteDesktop = Read-RegistrySnapshot -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Names @('fDenyTSConnections')
        RdpTransport = Read-RegistrySnapshot -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Names @('PortNumber','UserAuthentication','SecurityLayer','MinEncryptionLevel')
        RemoteAssistance = Read-RegistrySnapshot -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Names @('fAllowToGetHelp','fAllowFullControl')
        TerminalServicesPolicy = Read-RegistrySnapshot -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Names @(
                'fDenyTSConnections',
                'UserAuthentication',
                'SecurityLayer',
                'MinEncryptionLevel',
                'fAllowToGetHelp',
                'fAllowUnsolicited',
                'fAllowUnsolicitedFullControl'
            )
    }
}

$report.RemoteAccessServices = Invoke-AuditSection {
    $names = @(
        'TermService','SessionEnv','UmRdpService','WinRM','RemoteRegistry','sshd',
        'LanmanServer','RemoteAccess','RasMan','SstpSvc'
    )
    @(Get-CimInstance -ClassName Win32_Service -ErrorAction Stop | Where-Object {
        $_.Name -in $names
    } | ForEach-Object {
        [pscustomobject]@{
            Name      = $_.Name
            DisplayName = $_.DisplayName
            State     = $_.State
            StartMode = $_.StartMode
        }
    })
}

$report.SMBServerConfiguration = Invoke-AuditSection {
    $smb = Get-SmbServerConfiguration -ErrorAction Stop
    [pscustomobject]@{
        EnableSMB1Protocol          = Read-ObjectProperty $smb 'EnableSMB1Protocol'
        EnableSMB2Protocol          = Read-ObjectProperty $smb 'EnableSMB2Protocol'
        RequireSecuritySignature    = Read-ObjectProperty $smb 'RequireSecuritySignature'
        EnableSecuritySignature     = Read-ObjectProperty $smb 'EnableSecuritySignature'
        EncryptData                 = Read-ObjectProperty $smb 'EncryptData'
        RejectUnencryptedAccess     = Read-ObjectProperty $smb 'RejectUnencryptedAccess'
        EnableAuthenticateUserSharing = Read-ObjectProperty $smb 'EnableAuthenticateUserSharing'
        AutoShareServer             = Read-ObjectProperty $smb 'AutoShareServer'
        AutoShareWorkstation        = Read-ObjectProperty $smb 'AutoShareWorkstation'
        EnableSMBQUIC               = Read-ObjectProperty $smb 'EnableSMBQUIC'
        BlockNTLM                   = Read-ObjectProperty $smb 'BlockNTLM'
        Smb2DialectMin              = Read-ObjectProperty $smb 'Smb2DialectMin'
        Smb2DialectMax              = Read-ObjectProperty $smb 'Smb2DialectMax'
    }
}

$report.SMBClientConfiguration = Invoke-AuditSection {
    $smb = Get-SmbClientConfiguration -ErrorAction Stop
    [pscustomobject]@{
        EnableInsecureGuestLogons = Read-ObjectProperty $smb 'EnableInsecureGuestLogons'
        RequireSecuritySignature  = Read-ObjectProperty $smb 'RequireSecuritySignature'
        EnableSecuritySignature   = Read-ObjectProperty $smb 'EnableSecuritySignature'
        EnableSMBQUIC             = Read-ObjectProperty $smb 'EnableSMBQUIC'
        BlockNTLM                 = Read-ObjectProperty $smb 'BlockNTLM'
        Smb2DialectMin            = Read-ObjectProperty $smb 'Smb2DialectMin'
        Smb2DialectMax            = Read-ObjectProperty $smb 'Smb2DialectMax'
    }
}

$report.SMB1OptionalFeature = Invoke-AuditSection {
    if (-not (Get-Command -Name Get-WindowsOptionalFeature -ErrorAction SilentlyContinue)) {
        throw 'Windows optional-feature cmdlet is unavailable.'
    }
    $featureNames = @('SMB1Protocol','SMB1Protocol-Client','SMB1Protocol-Server')
    @($featureNames | ForEach-Object {
        $featureName = [string] $_
        try {
            $feature = Get-WindowsOptionalFeature -Online -FeatureName $featureName -ErrorAction Stop
            [pscustomobject]@{ FeatureName = $feature.FeatureName; State = [string] $feature.State }
        }
        catch {
            [pscustomobject]@{
                FeatureName = $featureName
                State       = 'UnavailableOrDenied'
                ErrorId     = [string] $_.FullyQualifiedErrorId
            }
        }
    })
}

$report.ActiveSMBShares = Invoke-AuditSection {
    @(Get-SmbShare -ErrorAction Stop | ForEach-Object {
        $share = $_
        try {
            $access = @(Get-SmbShareAccess -Name $share.Name -ErrorAction Stop | ForEach-Object {
                [pscustomobject]@{
                    AccountName       = $_.AccountName
                    AccessControlType = [string] $_.AccessControlType
                    AccessRight       = [string] $_.AccessRight
                }
            })
        }
        catch {
            $access = @([pscustomobject]@{
                Status  = 'UnavailableOrDenied'
                ErrorId = [string] $_.FullyQualifiedErrorId
            })
        }

        [pscustomobject]@{
            Name                  = $share.Name
            ScopeName             = $share.ScopeName
            ShareState            = [string] $share.ShareState
            Special               = $share.Special
            Temporary             = $share.Temporary
            EncryptData           = $share.EncryptData
            FolderEnumerationMode = [string] $share.FolderEnumerationMode
            Access                = $access
            Path                  = '<omitted>'
        }
    })
}

$report.LocalUsers = Invoke-AuditSection {
    if (-not (Get-Command -Name Get-LocalUser -ErrorAction SilentlyContinue)) {
        throw 'Microsoft.PowerShell.LocalAccounts cmdlets are unavailable.'
    }
    @(Get-LocalUser -ErrorAction Stop | ForEach-Object {
        [pscustomobject]@{
            Name                   = $_.Name
            Enabled                = $_.Enabled
            PrincipalSource        = [string] $_.PrincipalSource
            LastLogon              = $_.LastLogon
            PasswordRequired       = $_.PasswordRequired
            PasswordExpires        = $_.PasswordExpires
            UserMayChangePassword  = $_.UserMayChangePassword
            PasswordLastSet        = $_.PasswordLastSet
            IsBuiltInAdministrator = ([string] $_.SID) -match '-500$'
            IsBuiltInGuest         = ([string] $_.SID) -match '-501$'
        }
    })
}

$report.LocalPrivilegedGroups = Invoke-AuditSection {
    if (-not (Get-Command -Name Get-LocalGroup -ErrorAction SilentlyContinue)) {
        throw 'Microsoft.PowerShell.LocalAccounts cmdlets are unavailable.'
    }
    $wellKnownGroups = [ordered]@{
        Administrators       = 'S-1-5-32-544'
        RemoteDesktopUsers   = 'S-1-5-32-555'
    }

    @($wellKnownGroups.GetEnumerator() | ForEach-Object {
        $label = $_.Key
        try {
            $group = Get-LocalGroup -SID $_.Value -ErrorAction Stop
            $members = @(Get-LocalGroupMember -Group $group.Name -ErrorAction Stop | ForEach-Object {
                [pscustomobject]@{
                    Name            = $_.Name
                    ObjectClass     = [string] $_.ObjectClass
                    PrincipalSource = [string] $_.PrincipalSource
                }
            })
            [pscustomobject]@{
                Role    = $label
                Group   = $group.Name
                Members = $members
            }
        }
        catch {
            [pscustomobject]@{
                Role    = $label
                Status  = 'UnavailableOrDenied'
                ErrorId = [string] $_.FullyQualifiedErrorId
            }
        }
    })
}

$report.AutomaticLogon = Invoke-AuditSection {
    $path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
    [pscustomobject]@{
        AutoAdminLogon                  = Read-RegistryValue $path 'AutoAdminLogon'
        ForceAutoLogon                  = Read-RegistryValue $path 'ForceAutoLogon'
        DefaultUserNameValuePresent     = Test-RegistryValuePresent $path 'DefaultUserName'
        DefaultDomainNameValuePresent   = Test-RegistryValuePresent $path 'DefaultDomainName'
        DefaultPasswordValuePresent     = Test-RegistryValuePresent $path 'DefaultPassword'
        DisableCAD                      = Read-RegistryValue $path 'DisableCAD'
        ValuesDeliberatelyNotRead       = @('DefaultUserName','DefaultDomainName','DefaultPassword')
    }
}

$report.WindowsUpdate = Invoke-AuditSection {
    $updateServiceNames = @('wuauserv','UsoSvc','WaaSMedicSvc','BITS')
    $services = @(Get-CimInstance -ClassName Win32_Service -ErrorAction Stop | Where-Object {
        $_.Name -in $updateServiceNames
    } | ForEach-Object {
        [pscustomobject]@{
            Name      = $_.Name
            State     = $_.State
            StartMode = $_.StartMode
        }
    })

    $auPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
    $wuPolicyPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
    $uxPath = 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings'

    $hotFixes = @(Get-CimInstance -ClassName Win32_QuickFixEngineering -ErrorAction Stop |
        Sort-Object InstalledOn -Descending |
        Select-Object -First 15 |
        ForEach-Object {
            [pscustomobject]@{
                HotFixID    = $_.HotFixID
                InstalledOn = $_.InstalledOn
            }
        })

    try {
        $updateEvents = @(Get-WinEvent -FilterHashtable @{
            LogName   = 'Microsoft-Windows-WindowsUpdateClient/Operational'
            StartTime = (Get-Date).AddDays(-30)
            Id        = @(19,20,25,31)
        } -MaxEvents 50 -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{
                TimeCreated      = $_.TimeCreated
                Id               = $_.Id
                LevelDisplayName = $_.LevelDisplayName
            }
        })
    }
    catch {
        $updateEvents = @([pscustomobject]@{
            Status  = 'UnavailableOrNoMatchingEvents'
            ErrorId = [string] $_.FullyQualifiedErrorId
        })
    }

    [pscustomobject]@{
        Services = $services
        AutomaticUpdatePolicy = Read-RegistrySnapshot $auPath @(
            'NoAutoUpdate','AUOptions','ScheduledInstallDay','ScheduledInstallTime',
            'UseWUServer','DetectionFrequencyEnabled','DetectionFrequency'
        )
        WindowsUpdatePolicy = [pscustomobject]@{
            DisableWindowsUpdateAccess = Read-RegistryValue $wuPolicyPath 'DisableWindowsUpdateAccess'
            DoNotConnectToWindowsUpdateInternetLocations = Read-RegistryValue $wuPolicyPath 'DoNotConnectToWindowsUpdateInternetLocations'
            SetDisableUXWUAccess = Read-RegistryValue $wuPolicyPath 'SetDisableUXWUAccess'
            HasManagedUpdateServerValue = Test-RegistryValuePresent $wuPolicyPath 'WUServer'
            ManagedUpdateServerValueOmitted = $true
        }
        PauseSettings = Read-RegistrySnapshot $uxPath @(
            'PauseUpdatesStartTime','PauseUpdatesExpiryTime',
            'PauseQualityUpdatesStartTime','PauseQualityUpdatesEndTime',
            'PauseFeatureUpdatesStartTime','PauseFeatureUpdatesEndTime'
        )
        RebootPendingIndicators = [pscustomobject]@{
            ComponentBasedServicing = Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
            WindowsUpdate           = Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
            PendingFileRenameValue  = Test-RegistryValuePresent 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'PendingFileRenameOperations'
        }
        MostRecentQuickFixes = $hotFixes
        RecentUpdateEvents   = $updateEvents
        UpdateSearchWasStarted = $false
    }
}

$report.ListeningTCPPorts = Invoke-AuditSection {
    $processNames = @{}
    foreach ($process in @(Get-CimInstance -ClassName Win32_Process -ErrorAction Stop)) {
        $processNames[[int] $process.ProcessId] = $process.Name
    }

    $servicesByProcess = @{}
    foreach ($service in @(Get-CimInstance -ClassName Win32_Service -ErrorAction Stop)) {
        $pidValue = [int] $service.ProcessId
        if ($pidValue -gt 0) {
            $servicesByProcess[$pidValue] = @($servicesByProcess[$pidValue]) + $service.Name
        }
    }

    @(Get-NetTCPConnection -State Listen -ErrorAction Stop | ForEach-Object {
        $address = [string] $_.LocalAddress
        $bindScope = if ($address -in @('0.0.0.0','::')) {
            'AnyInterface'
        }
        elseif ($address -in @('127.0.0.1','::1')) {
            'LoopbackOnly'
        }
        else {
            'SpecificInterface'
        }
        $pidValue = [int] $_.OwningProcess

        [pscustomobject]@{
            LocalPort       = $_.LocalPort
            AddressFamily   = if ($address.Contains(':')) { 'IPv6' } else { 'IPv4' }
            BindScope       = $bindScope
            OwningProcessId = $pidValue
            ProcessName     = $processNames[$pidValue]
            ServiceNames    = @($servicesByProcess[$pidValue] | Select-Object -Unique)
        }
    } | Sort-Object LocalPort, AddressFamily, OwningProcessId)
}

$report.RemoteControlSoftwareIndicators = Invoke-AuditSection {
    $remoteControlPattern = '(?i)anydesk|teamviewer|rustdesk|screenconnect|connectwise\s*(control)?|splashtop|chrome\s*remote\s*desktop|chromoting|remotepc|logmein|gotoassist|goto\s*resolve|zoho\s*assist|dwagent|supremo|ultravnc|tightvnc|realvnc|vnc\s*(server|viewer)|meshagent|meshcentral|simplehelp|bomgar|beyondtrust\s*remote|dameware|radmin|atera|n-able\s*take\s*control|netop\s*remote|parsec|nomachine|ammyy|aeroadmin|remote\s*utilities|pulseway'
    $remoteNetworkPattern = '(?i)tailscale|zerotier|hamachi|ngrok|cloudflared|wireguard|radmin\s*vpn'

    $tasks = @()
    if (Get-Command -Name Get-ScheduledTask -ErrorAction SilentlyContinue) {
        foreach ($task in @(Get-ScheduledTask -ErrorAction Stop)) {
            $actions = @($task.Actions)
            $matchText = [string] ($task.TaskName, $task.TaskPath,
                ($actions | ForEach-Object { $_.Execute }),
                ($actions | ForEach-Object { $_.Arguments }) -join ' ')
            if ($matchText -match $remoteControlPattern -or $matchText -match $remoteNetworkPattern) {
                $tasks += [pscustomobject]@{
                    TaskName       = $task.TaskName
                    TaskPath       = $task.TaskPath
                    State          = [string] $task.State
                    ActionFiles    = @($actions | ForEach-Object {
                        Get-SafeExecutableLeaf -Value ([string] $_.Execute)
                    } | Where-Object { $_ } | Select-Object -Unique)
                    ArgumentsOmitted = $true
                    IndicatorType  = if ($matchText -match $remoteControlPattern) {
                        'RemoteControl'
                    } else {
                        'RemoteNetworkOverlay'
                    }
                }
            }
        }
    }

    $installed = @()
    $uninstallRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    foreach ($root in $uninstallRoots) {
        if (Test-Path -LiteralPath $root) {
            foreach ($key in @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
                try {
                    $displayName = [string] $key.GetValue('DisplayName', $null,
                        [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                    $publisher = [string] $key.GetValue('Publisher', $null,
                        [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                    $matchText = "$displayName $publisher"
                    if ($matchText -match $remoteControlPattern -or $matchText -match $remoteNetworkPattern) {
                        $installed += [pscustomobject]@{
                            DisplayName   = $displayName
                            Publisher     = $publisher
                            Scope         = if ($root.StartsWith('HKCU:')) { 'CurrentUser' } else { 'Machine' }
                            IndicatorType = if ($matchText -match $remoteControlPattern) {
                                'RemoteControl'
                            } else {
                                'RemoteNetworkOverlay'
                            }
                        }
                    }
                }
                catch { }
            }
        }
    }

    $services = @(Get-CimInstance -ClassName Win32_Service -ErrorAction Stop | Where-Object {
        $matchText = [string] ($_.Name, $_.DisplayName, $_.PathName -join ' ')
        $matchText -match $remoteControlPattern -or $matchText -match $remoteNetworkPattern
    } | ForEach-Object {
        $matchText = [string] ($_.Name, $_.DisplayName, $_.PathName -join ' ')
        [pscustomobject]@{
            Name           = $_.Name
            DisplayName    = $_.DisplayName
            State          = $_.State
            StartMode      = $_.StartMode
            ExecutableFile = Get-SafeExecutableLeaf -Value $_.PathName
            PathOmitted    = $true
            IndicatorType  = if ($matchText -match $remoteControlPattern) {
                'RemoteControl'
            } else {
                'RemoteNetworkOverlay'
            }
        }
    })

    $processes = @(Get-CimInstance -ClassName Win32_Process -ErrorAction Stop | Where-Object {
        $_.Name -match $remoteControlPattern -or $_.Name -match $remoteNetworkPattern
    } | ForEach-Object {
        [pscustomobject]@{
            ProcessId     = $_.ProcessId
            Name          = $_.Name
            IndicatorType = if ($_.Name -match $remoteControlPattern) {
                'RemoteControl'
            } else {
                'RemoteNetworkOverlay'
            }
        }
    })

    $startup = @()
    $startupKeys = [ordered]@{
        MachineRun     = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
        MachineRunOnce = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
        UserRun        = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
        UserRunOnce    = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
    }
    foreach ($entry in $startupKeys.GetEnumerator()) {
        try {
            $key = Get-Item -LiteralPath $entry.Value -ErrorAction Stop
            foreach ($valueName in @($key.GetValueNames())) {
                $valueData = [string] $key.GetValue($valueName, $null,
                    [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                $matchText = "$valueName $valueData"
                if ($matchText -match $remoteControlPattern -or $matchText -match $remoteNetworkPattern) {
                    $startup += [pscustomobject]@{
                        Location       = $entry.Key
                        ValueName      = $valueName
                        ExecutableFile = Get-SafeExecutableLeaf -Value $valueData
                        ValueDataOmitted = $true
                        IndicatorType  = if ($matchText -match $remoteControlPattern) {
                            'RemoteControl'
                        } else {
                            'RemoteNetworkOverlay'
                        }
                    }
                }
            }
        }
        catch { }
    }

    [pscustomobject]@{
        InstalledPrograms = $installed
        Services          = $services
        RunningProcesses  = $processes
        ScheduledTasks    = $tasks
        StartupEntries    = $startup
        FullPathsOmitted  = $true
        FindingIsNotProofOfUnauthorizedUse = $true
    }
}

$report.WindowsHelloPolicy = Invoke-AuditSection {
    $tenantPolicies = @()
    $tenantRoot = 'HKLM:\SOFTWARE\Microsoft\Policies\PassportForWork'
    if (Test-Path -LiteralPath $tenantRoot) {
        foreach ($tenantKey in @(Get-ChildItem -LiteralPath $tenantRoot -ErrorAction SilentlyContinue)) {
            $devicePolicyPath = Join-Path -Path $tenantKey.PSPath -ChildPath 'Device\Policies'
            if (Test-Path -LiteralPath $devicePolicyPath) {
                $tenantPolicies += Read-RegistrySnapshot $devicePolicyPath @(
                    'UsePassportForWork','RequireSecurityDevice','UseBiometrics',
                    'PINRecovery','UseCloudTrustForOnPremAuth'
                )
            }
        }
    }

    [pscustomobject]@{
        GroupPolicy = Read-RegistrySnapshot -Path 'HKLM:\SOFTWARE\Policies\Microsoft\PassportForWork' -Names @(
                'Enabled','RequireSecurityDevice','UseBiometrics','PINRecovery',
                'DisablePostLogonProvisioning'
            )
        PolicyManagerCurrent = Read-RegistrySnapshot -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\PassportForWork' -Names @('Enabled','RequireSecurityDevice','UseBiometrics')
        TenantPolicySetCount = $tenantPolicies.Count
        TenantPolicySettings = $tenantPolicies
        TenantIdentifiersOmitted = $true
        EnrollmentState = 'Not proven by policy; credential-container metadata was deliberately not inspected.'
    }
}

$report.BiometricDevices = Invoke-AuditSection {
    @(Get-CimInstance -ClassName Win32_BiometricDevice -ErrorAction Stop | ForEach-Object {
        [pscustomobject]@{
            Name                   = $_.Name
            Status                 = $_.Status
            Availability           = $_.Availability
            ConfigManagerErrorCode = $_.ConfigManagerErrorCode
        }
    })
}

$report.WindowsHelloServices = Invoke-AuditSection {
    $helloServiceNames = @('NgcSvc','NgcCtnrSvc','WbioSrvc')
    @(Get-CimInstance -ClassName Win32_Service -ErrorAction Stop | Where-Object {
        $_.Name -in $helloServiceNames
    } | ForEach-Object {
        [pscustomobject]@{
            Name      = $_.Name
            State     = $_.State
            StartMode = $_.StartMode
        }
    })
}

$report.RecentSecurityEvents = Invoke-AuditSection {
    $logInfo = Get-WinEvent -ListLog Security -ErrorAction Stop
    $interestingIds = @(
        1102, 4616, 4624, 4625, 4697, 4698, 4699, 4702, 4719,
        4720, 4722, 4724, 4725, 4726, 4732, 4733, 4738, 4740
    )
    $events = @(Get-WinEvent -FilterHashtable @{
        LogName   = 'Security'
        StartTime = $eventWindowStart
        Id        = $interestingIds
    } -MaxEvents $MaximumSecurityEvents -ErrorAction Stop)

    $counts = @($events | Group-Object Id | Sort-Object Name | ForEach-Object {
        [pscustomobject]@{
            EventId       = [int] $_.Name
            CountInSample = $_.Count
        }
    })

    $remoteLogons = @()
    $securityChanges = @()
    foreach ($event in $events) {
        $data = Get-EventDataMap -EventRecord $event
        if ($event.Id -in @(4624,4625)) {
            $logonType = Get-FirstMapValue $data @('LogonType')
            if ($logonType -in @('3','8','10')) {
                $sourceAddress = Get-FirstMapValue $data @('IpAddress','WorkstationName')
                if ($sourceAddress -in @('-','127.0.0.1','::1')) {
                    $sourceAddress = $null
                }
                $remoteLogons += [pscustomobject]@{
                    TimeCreated  = $event.TimeCreated
                    EventId      = $event.Id
                    Result       = if ($event.Id -eq 4624) { 'Success' } else { 'Failure' }
                    LogonType    = [int] $logonType
                    TargetUser   = Get-FirstMapValue $data @('TargetUserName')
                    Source       = $sourceAddress
                    AuthenticationPackage = Get-FirstMapValue $data @('AuthenticationPackageName')
                }
            }
        }
        else {
            $changedObject = switch ($event.Id) {
                4697 { Get-FirstMapValue $data @('ServiceName') }
                { $_ -in @(4698,4699,4702) } { Get-FirstMapValue $data @('TaskName') }
                { $_ -in @(4720,4722,4724,4725,4726,4738,4740) } {
                    Get-FirstMapValue $data @('TargetUserName')
                }
                { $_ -in @(4732,4733) } {
                    Get-FirstMapValue $data @('MemberName','MemberSid')
                }
                default { $null }
            }
            $securityChanges += [pscustomobject]@{
                TimeCreated   = $event.TimeCreated
                EventId       = $event.Id
                Actor         = Get-FirstMapValue $data @('SubjectUserName')
                ChangedObject = $changedObject
                TargetGroup   = Get-FirstMapValue $data @('TargetUserName')
                FullMessageOmitted = $true
            }
        }
    }

    [pscustomobject]@{
        LogEnabled        = $logInfo.IsEnabled
        LogMode           = [string] $logInfo.LogMode
        RecordCount       = $logInfo.RecordCount
        LastWriteTime     = $logInfo.LastWriteTime
        RequestedDays     = $RecentEventDays
        MaximumEventsRead = $MaximumSecurityEvents
        EventsRead        = $events.Count
        CountsByEventId   = $counts
        RemoteLikeLogons  = @($remoteLogons | Select-Object -First 100)
        SecurityChanges   = @($securityChanges | Select-Object -First 100)
        FullMessagesRead  = $false
        CompleteHistoryGuaranteed = $false
    }
}

[pscustomobject] $report | ConvertTo-Json -Depth 12
