# Security and privacy policy

## Supported versions

Until a stable release policy exists, only the newest revision on the default branch is intended to receive security fixes.

## Reporting a vulnerability

After this repository is published, use GitHub's private security-advisory feature when available. Do not disclose a vulnerability or real audit data in a public issue. If private advisories are not enabled, open a minimal issue asking the maintainer to establish a private contact channel and include no sensitive details.

Please report behavior such as:

- a command that changes system, registry, service, firewall, Defender, update, BitLocker, logging, or account state;
- a malware scan, update search, network request, installation, or self-elevation attempt;
- output written to disk without an explicit caller-controlled redirection;
- disclosure of a value the script promises to omit;
- an unbounded or unexpectedly broad event-log query; or
- a fixed personal filesystem path or committed real audit result.

## Safe reproduction

Do not attach output from a real machine. Reproduce parser or formatting bugs with synthetic objects when possible. If a machine-specific issue cannot be reproduced synthetically, first arrange a private channel and redact usernames, source addresses, account principals, share names, process information, device details, timestamps, and identifiers.

## Scope and limitations

The script is an informational snapshot, not a vulnerability scanner, compliance certification, incident-response conclusion, or remediation tool. Static checks help catch known unsafe command names but do not constitute a formal side-effect proof. Review changes before running them on a real system.
