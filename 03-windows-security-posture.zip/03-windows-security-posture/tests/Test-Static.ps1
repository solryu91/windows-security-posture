[CmdletBinding()]
param(
    [string] $ScriptPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ScriptPath)) {
    $testDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
    $ScriptPath = Join-Path -Path $testDirectory -ChildPath '..\windows-security-audit-readonly.ps1'
}

$resolvedScript = (Resolve-Path -LiteralPath $ScriptPath).Path
$tokens = $null
$parseErrors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile(
    $resolvedScript,
    [ref] $tokens,
    [ref] $parseErrors
)

if ($parseErrors.Count -gt 0) {
    $details = @($parseErrors | ForEach-Object {
        'Line {0}, column {1}: {2}' -f $_.Extent.StartLineNumber, $_.Extent.StartColumnNumber, $_.Message
    }) -join [Environment]::NewLine
    throw "PowerShell parser errors were found:$([Environment]::NewLine)$details"
}

$forbiddenCommands = @(
    'Add-Content',
    'Add-MpPreference',
    'Clear-Content',
    'Clear-EventLog',
    'Copy-Item',
    'Disable-BitLocker',
    'Disable-NetFirewallRule',
    'Enable-BitLocker',
    'Enable-NetFirewallRule',
    'Export-Clixml',
    'Install-Module',
    'Invoke-RestMethod',
    'Invoke-WebRequest',
    'Move-Item',
    'New-EventLog',
    'New-Item',
    'New-ItemProperty',
    'New-NetFirewallRule',
    'Out-File',
    'Remove-EventLog',
    'Remove-Item',
    'Remove-ItemProperty',
    'Remove-MpPreference',
    'Remove-NetFirewallRule',
    'Rename-Item',
    'Restart-Computer',
    'Restart-Service',
    'Set-Content',
    'Set-Item',
    'Set-ItemProperty',
    'Set-MpPreference',
    'Set-NetFirewallProfile',
    'Set-NetFirewallRule',
    'Set-Service',
    'Start-BitsTransfer',
    'Start-MpScan',
    'Start-Process',
    'Start-Service',
    'Start-Transcript',
    'Stop-Computer',
    'Stop-Service',
    'Tee-Object',
    'Update-Module',
    'Update-MpSignature',
    'auditpol.exe',
    'manage-bde.exe',
    'netsh.exe',
    'reg.exe',
    'sc.exe',
    'schtasks.exe',
    'shutdown.exe'
)

$commandNames = @($ast.FindAll({
    param($node)
    $node -is [System.Management.Automation.Language.CommandAst]
}, $true) | ForEach-Object {
    $_.GetCommandName()
} | Where-Object {
    -not [string]::IsNullOrWhiteSpace($_)
})

$forbiddenFound = @($commandNames | Where-Object { $_ -in $forbiddenCommands } | Sort-Object -Unique)
if ($forbiddenFound.Count -gt 0) {
    throw "Potentially mutating or network commands were found: $($forbiddenFound -join ', ')"
}

$source = Get-Content -LiteralPath $resolvedScript -Raw
if ($source -match '(?i)[A-Z]:\\Users\\') {
    throw 'A fixed Windows user-profile path was found.'
}

Write-Host "Static checks passed: no parser errors, fixed user paths, or forbidden commands were found."
